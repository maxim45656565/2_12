package com.example.myapplication212;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText modelEditText;
    private EditText serialNumberEditText;
    private EditText priceEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        modelEditText = findViewById(R.id.modelEditText);
        serialNumberEditText = findViewById(R.id.serialNumberEditText);
        priceEditText = findViewById(R.id.priceEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String model = modelEditText.getText().toString();
                String serialNumber = serialNumberEditText.getText().toString();
                int price = Integer.parseInt(priceEditText.getText().toString());

                Phone phone = new Phone(model, serialNumber, price);
                DatabaseHelper databaseHelper = new DatabaseHelper(MainActivity.this);
                databaseHelper.insertPhone(phone);

                modelEditText.setText("");
                serialNumberEditText.setText("");
                priceEditText.setText("");

                Intent intent = new Intent(MainActivity.this, PhoneListActivity.class);
                startActivity(intent);
            }
        });
    }
}