package com.example.myapplication212;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "phones.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "phones";
    private static final String COLUMN_MODEL = "model";
    private static final String COLUMN_SERIAL_NUMBER = "serial_number";
    private static final String COLUMN_PRICE = "price";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_MODEL + " TEXT, " +
                COLUMN_SERIAL_NUMBER + " TEXT, " +
                COLUMN_PRICE + " INTEGER)";

        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String dropTableQuery = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(dropTableQuery);
        onCreate(db);
    }

    public void insertPhone(Phone phone) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_MODEL, phone.getModel());
        values.put(COLUMN_SERIAL_NUMBER, phone.getSerialNumber());
        values.put(COLUMN_PRICE, phone.getPrice());
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public List<Phone> getAllPhones() {
        List<Phone> phoneList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        if (cursor.moveToFirst()) {
            do {
                String model = cursor.getString(cursor.getColumnIndex(COLUMN_MODEL));
                String serialNumber = cursor.getString(cursor.getColumnIndex(COLUMN_SERIAL_NUMBER));
                int price = cursor.getInt(cursor.getColumnIndex(COLUMN_PRICE));

                Phone phone = new Phone(model, serialNumber, price);
                phoneList.add(phone);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return phoneList;
    }
}